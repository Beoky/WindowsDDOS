# DDoSPacket-For-Windows
DDoSPacket For Windows (Recommend Windows 8+)

![DDoSPacketWindowsIcon](https://user-images.githubusercontent.com/47820634/161378851-3a6d57a5-b69d-4896-b8c8-67ea8b542b91.png)
# What is DDoS Packet
* DDoS Packet is ddos program write with C# and .NET for Troll someone or education
# Warning
* We are not responsible for any damage caused by this program please legally to use only!
# Screenshot
![image](https://user-images.githubusercontent.com/47820634/161378989-47f62324-c646-4e5d-b3da-827dd3cb5b00.png)
# Methods
* UDP
* TCP
* ICMP
* HTTP/GET (Unstable)
# Common issues
* For tcp procotol if you starting attack and then that crash make sure target port are opened (we need connecting to server first)
* for udp and other sometimes attacking is working but target not got any packet (mean ISP are blocked or good firewall)
# Other platform version
DDoS Packet is have 2 platform support (Windows and Android)
* [Windows](https://github.com/fusedevgithub/DDoSPacket-For-Windows/)
* [Android](https://github.com/fusedevgithub/DDoSPacket) (Original)
