﻿using System;
using System.Net;

namespace FuseDDoS_Version_3
{
    internal class client
    {
        internal static void Disconnect(bool v)
        {
            throw new NotImplementedException();
        }

        internal static void Connect(IPEndPoint endPoint)
        {
            throw new NotImplementedException();
        }
    }
}